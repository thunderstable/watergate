import { createRouter, createWebHistory } from 'vue-router'
import Home from '../components/indashboard';
import Dashboard from '../components/dashboard';

const routes = [
  {
    path: '/',
    name: 'Dashboard',
    component: Dashboard
  },
  {
    path: '/dashboard',
    name: 'Home',
    component: Home
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
