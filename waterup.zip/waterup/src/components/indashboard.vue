<template>
  <nav class="navbar navbar-expand-lg navbar-light  fixed-top" style="background-color:#212120 ; height:70px;">
    <div class="container-fluid">
        <router-link to="/" style="text-decoration: none; color: inherit;">
      <a class="navbar-brand" href="#" style="font-weight:bold;color:#e54003;">
        <fa icon="home" style="width:30px;height:25px;" />HOME |</a>
             </router-link>

      <div class="text-white">ปตร.กลางคลองระพีพัฒน์แยกตก</div>

      <!-- <div style="color:white"><a>หน้าบาน : <a style="color:#1da32e;">5.55 เมตร</a></a></div>
    &nbsp;
    <div style="color:white">|</div>
    &nbsp;
    <div style="color:white"><a>หลังบาน : <a style="color:#1da32e;">5.55 เมตร</a></a></div> -->
    </div>
  </nav>

  <main style="background-color:;height:100vh; margin-left:1%; margin-right:1%;">
    <div style="height:55px;"></div>
    <div class="row mt-3" style="height:45px;background-color:#CFCFCF;">
      <div class="col ms-3 mt-1  fs-4">การแสดงผล <a>|</a><a style="font-size:12px;"> Monitor</a> </div>
    </div>
    <div class=" mt-1">
      <div class="row">


        <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-4 mt-3">
          <div class="  border">
            <div class="row">
              <div class="col-6 border bg-light ms-4 my-3">
                <div class="fs-6 mt-2 ms-4 " style="font-weight:bold;color:#424242;">กราฟความสูงระดับน้ำ</div>
                <div id="chart">
                  <apexchart type="bar" height="300" :options="chartOptions4" :series="series4"></apexchart>
                </div>
              </div>
              <div class="col mt-3">
                <div class="fs-6 mt-2 mx-4" style="font-weight:bold;color:#424242;height:345px;">
                  <div>ความสูงน้ำหน้าบาน | หลังบาน</div>
                  <div class=" mt-2 rounded-3" style="height:120px;background-color:">
                    <div class=" mt-3 text-center"><a style="font-size:48px;color:#1da32e;">6.54
                        <a style="font-size:16px; text-decoration: underline; ">เมตร</a>
                      </a>
                      <div>ระดับน้ำหน้าบาน</div>
                    </div>
                  </div>
                  <hr>
                  <div class=" mt-2 rounded-3" style="height:120px;background-color:">
                    <div class=" mt-3 text-center"><a style="font-size:48px;color:#d39a33">4.56
                        <a style="font-size:16px; text-decoration: underline; ">เมตร</a>
                      </a>
                      <div>ระดับน้ำหลังบาน</div>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-4 mt-3">
          <div class="row border">
            <div class="col-7">
              <div class="ms-2 my-3 border bg-light">
                <div class="fs-6 mt-2 mx-4 mt-3" style="font-weight:bold;color:#424242;height:330px;">
                  <div style="font-weight:bold;">
                    ความสูงบานประตู
                  </div>
                  <div>
                    <div id="chart">
                      <apexchart type="bar" height="300" :options="chartOptions5" :series="series5"></apexchart>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col mt-3">
              <div style="font-weight:bold;">ความสูงบานประตู</div>
              <div class="mt-5">
                บานที่หนึ่ง
              </div>
              <div class="fs-3 text-end me-5" style="font-weight:bold; color:#566573;">3.5 เมตร</div>
              <div>
                บานที่สอง
              </div>
              <div class="fs-3 text-end me-5" style="font-weight:bold; color:#566573;">2.5 เมตร</div>
              <div>
                บานที่สาม
              </div>
              <div class="fs-3 text-end me-5" style="font-weight:bold; color:#566573;">4.5 เมตร</div>
              <div>
                บานที่สี่
              </div>
              <div class="fs-3 text-end me-5" style="font-weight:bold; color:#566573;">2.5 เมตร</div>
            </div>
          </div>
        </div>

        <div class="col-12 col-sm-12 col-md-5 col-lg-4 col-xl-4 mt-3">
          <div class="  border">
            <div class="fs-5 mt-2 mx-4" style="font-weight:bold;color:#424242;height:372px;">
              <div>สถานะการทำงาน</div>
              <div class="row  justify-content-center">
                <div class="col-3">
                  <img class="" alt="Vue logo" :src="require('@/assets/motor.jpg')" style="max-width:120px;">
                </div>
              </div>
              <!-- <div class="row mt-1" style="height:100px;">
                        <div class="col border mt-2 ms-2 text-center mt-2 ms-2"><div class="mt-2" style="font-size:18px;">MORTOR 1 </div>
                          <div style="font-size:12px;">บานที่หนึ่ง</div>
                        <span class="dot mt-2"></span>
                        </div>            
                    <div class="col border  mt-2 ms-2 text-center mt-2 ms-2"><div class="mt-2" style="font-size:18px;">MORTOR 1 </div>
                    <div style="font-size:12px;">บานที่หนึ่ง</div>
                    <span class="dot mt-2"></span>
                    </div> 
                  </div>
                  <div class="row mt-2" style="height:100px;">
                    <div class="col border mt-2 ms-2 text-center mt-2 ms-2"><div class="mt-2" style="font-size:18px;">MORTOR 1 </div>
                    <div style="font-size:12px;">บานที่หนึ่ง</div>
                    <span class="dot mt-2"></span>
                    </div>            
                
                    <div class="col border  mt-2 ms-2 text-center mt-2 ms-2"><div class="mt-2" style="font-size:18px;">MORTOR 1 </div>
                    <div style="font-size:12px;">บานที่หนึ่ง</div>
                    <span class="dot mt-2"></span>
                    </div> 
                  </div> -->

              <div class="fs-5 mt-2 mx-4" style="font-weight:bold;color:#424242;">
                <div class="mt-3"></div>
                <div class="text-center">RUN HOUR</div>
                <div class="text-center fs-3">0 : 0 HH:mm</div>
                <div class="mt-3"></div>
                <div>รายละเอียดสถานี</div>
                <a style="color:#3E3E3E;font-size:22px;"> สถานะ</a> <a style="color:#1da32e;"> Online</a>

                <div>Station ID: <a style="font-size:16px;">ADSITVCD12FDS</a></div>
                <div class="mb-5">ที่ตั้ง: <a style="font-size:16px;">ปตร.กลางคลองระพีพัฒน์แยกตก</a></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row mt-4" style="height:45px;background-color:#CFCFCF;">
        <div class="row">
          <div class="col-lg-8 col-md-8 col-sm-6 col-5 ms-3 mt-1 fs-5">การควบคุม <a>|</a><a style="font-size:12px;"> Control</a> </div>

          <div class="col-lg-2 col-md-2 col-sm-3 col-3 text-end">
            <div>MODE</div>
            <div style="font-size:13px;">รูปแบบควบคุม</div>
          </div>

          <div class="col-lg-1 col-md-1 col-sm-2 col-1 mt-2 text-start">

            <select v-model="optionM">
              <!-- <option value="เลือกความสูงบานประตู">เลือกความสูงบานประตู"</option> -->
              <option>ความสูงบานประตู</option>
              <option>ปริมาณน้ำ</option>
            </select>
          </div>
        </div>
      </div>

      <div v-if="optionM=='ความสูงบานประตู'" class="row mx-2 mt-2">
        <div class="row">

          <div class="col-12  col-xl-2 border mt-3  ms-2" style="font-weight:bold;color:#424242;height:340px;">
            <div class="fs-5 mt-2">
              <div>บานที่หนึ่ง | <a style="color:#F39C12;font-size:22px;">{{series3[0]}}</a> เมตร</div>
            </div>
            <div id="chart">
              <apexchart type="radialBar" height="200" :options="chartOptions3" :series="series3"></apexchart>
            </div>
            <div class="row justify-content-center">
              <div class="text-center">เลือกความสูงบานประตู</div>
              <div class=" text-center mt-1">
                <select v-model="series3[0]">
                  <option disabled value="เลือกความสูงบานประตู">เลือกความสูงบานประตู</option>
                  <option>0.0</option>
                  <option>0.5</option>
                  <option>1.0</option>
                  <option>1.5</option>
                  <option>2.0</option>
                  <option>2.5</option>
                  <option>3.0</option>
                  <option>3.5</option>
                  <option>4.0</option>
                  <option>4.5</option>
                </select>
              </div>
              <button type="button" class="btn text-white mt-3" style="background-color:rgb(213 86 38) !important ">
                <fa icon="check-circle" class="" style="width:20px;height:20px;" />&nbsp;ยืนยัน</button>
            </div>
          </div>

          <div class="col-12 col-xl-2 border mt-3  ms-2" style="font-weight:bold;color:#424242;height:340px;">
            <div class="fs-5 mt-2">
              <div>บานที่สอง | <a style="color:#F39C12;font-size:22px;">{{series3[0]}}</a> เมตร</div>
            </div>
            <div id="chart">
              <apexchart type="radialBar" height="200" :options="chartOptions3" :series="series3"></apexchart>
            </div>
            <div class="row justify-content-center">
              <div class="text-center">เลือกความสูงบานประตู</div>
              <div class=" text-center mt-1">
                <select v-model="series3[0]">
                  <option disabled value="เลือกความสูงบานประตู">เลือกความสูงบานประตู</option>
                  <option>0.0</option>
                  <option>0.5</option>
                  <option>1.0</option>
                  <option>1.5</option>
                  <option>2.0</option>
                  <option>2.5</option>
                  <option>3.0</option>
                  <option>3.5</option>
                  <option>4.0</option>
                  <option>4.5</option>
                </select>
              </div>
              <button type="button" class="btn text-white mt-3" style="background-color:rgb(213 86 38) !important ">
                <fa icon="check-circle" class="" style="width:20px;height:20px;" />&nbsp;ยืนยัน</button>
            </div>
          </div>

          <div class="col-12 col-xl-2 border mt-3  ms-2" style="font-weight:bold;color:#424242;height:340px;">
            <div class="fs-5 mt-2">
              <div>บานที่สาม | <a style="color:#F39C12;font-size:22px;">{{series3[0]}}</a> เมตร</div>
            </div>
            <div id="chart">
              <apexchart type="radialBar" height="200" :options="chartOptions3" :series="series3"></apexchart>
            </div>
            <div class="row justify-content-center">
              <div class="text-center">เลือกความสูงบานประตู</div>
              <div class=" text-center mt-1">
                <select v-model="series3[0]">
                  <option disabled value="เลือกความสูงบานประตู">เลือกความสูงบานประตู</option>
                  <option>0.0</option>
                  <option>0.5</option>
                  <option>1.0</option>
                  <option>1.5</option>
                  <option>2.0</option>
                  <option>2.5</option>
                  <option>3.0</option>
                  <option>3.5</option>
                  <option>4.0</option>
                  <option>4.5</option>
                </select>
              </div>
              <button type="button" class="btn text-white mt-3" style="background-color:rgb(213 86 38) !important ">
                <fa icon="check-circle" class="" style="width:20px;height:20px;" />&nbsp;ยืนยัน</button>
            </div>
          </div>

          <div class="col-12 col-xl-2 border mt-3  ms-2" style="font-weight:bold;color:#424242;height:340px;">
            <div class="fs-5 mt-2">
              <div>บานที่สี่ | <a style="color:#F39C12;font-size:22px;">{{series3[0]}}</a> เมตร</div>
            </div>
            <div id="chart">
              <apexchart type="radialBar" height="200" :options="chartOptions3" :series="series3"></apexchart>
            </div>
            <div class="row justify-content-center">
              <div class="text-center">เลือกความสูงบานประตู</div>
              <div class=" text-center mt-1">
                <select v-model="series3[0]">
                  <option disabled value="เลือกความสูงบานประตู">เลือกความสูงบานประตู</option>
                  <option>0.0</option>
                  <option>0.5</option>
                  <option>1.0</option>
                  <option>1.5</option>
                  <option>2.0</option>
                  <option>2.5</option>
                  <option>3.0</option>
                  <option>3.5</option>
                  <option>4.0</option>
                  <option>4.5</option>
                </select>
              </div>
              <button type="button" class="btn text-white mt-3" style="background-color:rgb(213 86 38) !important ">
                <fa icon="check-circle" class="" style="width:20px;height:20px;" />&nbsp;ยืนยัน</button>
            </div>
          </div>



          <!-- <div class="col-3 border mt-2  ms-2" style="font-weight:bold;color:#424242;height:340px;">
            <div class="text-center mt-3 fs-4">
              Some Content
            </div>
          </div> -->


          <!-- <div class="col border mt-2  ms-2" style="font-weight:bold;color:#424242;height:380px;">
            <div class="fs-5 mt-2">
              <div>บานที่สอง | <a style="color:#F39C12;font-size:16px;">ขณะนี้สูง 4.5 เมตร</a><a class="ms-2"> <button
                    type="button" class="btn text-white ms-5" style="background-color:#F39C12">
                    <fa icon="edit" class="" style="width:20px;height:20px;" />&nbsp;แก้ไขความสูง</button></a> </div>
            </div>
            <div id="chart">
              <apexchart type="radialBar" height="250" :options="chartOptions3" :series="series3"></apexchart>
            </div>
            <div class="row justify-content-center">
              <div class="col-7 mb-3" style="height:10px;">
                <Slider v-model="series3[0]" class="slider-red" />
              </div>
              <button type="button" class="btn text-white mt-5" style="background-color:rgb(213 86 38) !important ">
                <fa icon="check-circle" class="" style="width:20px;height:20px;" />&nbsp;ยืนยัน</button>
            </div>
          </div>

          <div class="col border mt-2  ms-2" style="font-weight:bold;color:#424242;height:380px;">
            <div class="fs-5 mt-2">
              <div>บานที่สาม | <a style="color:#F39C12;font-size:16px;">ขณะนี้สูง 4.5 เมตร</a><a class="ms-2"> <button
                    type="button" class="btn text-white ms-5" style="background-color:#F39C12">
                    <fa icon="edit" class="" style="width:20px;height:20px;" />&nbsp;แก้ไขความสูง</button></a> </div>
            </div>
            <div id="chart">
              <apexchart type="radialBar" height="250" :options="chartOptions3" :series="series3"></apexchart>
            </div>
            <div class="row justify-content-center">
              <div class="col-7 mb-3" style="height:10px;">
                <Slider v-model="series3[0]" class="slider-red" />
              </div>
              <button type="button" class="btn text-white mt-5" style="background-color:rgb(213 86 38) !important ">
                <fa icon="check-circle" class="" style="width:20px;height:20px;" />&nbsp;ยืนยัน</button>
            </div>
          </div>


          <div class="col border mt-2  ms-2" style="font-weight:bold;color:#424242;height:380px;">
            <div class="fs-5 mt-2">
              <div>บานที่สี่ | <a style="color:#F39C12;font-size:16px;">ขณะนี้สูง 4.5 เมตร</a><a class="ms-3"> <button
                    type="button" class="btn text-white ms-5" style="background-color:#F39C12">
                    <fa icon="edit" class="" style="width:20px;height:20px;" />&nbsp;แก้ไขความสูง</button></a> </div>
            </div>
            <div id="chart">
              <apexchart type="radialBar" height="250" :options="chartOptions3" :series="series3"></apexchart>
            </div>
            <div class="row justify-content-center">
              <div class="col-7 mb-3" style="height:10px;">
                <Slider v-model="series3[0]" class="slider-red" />
              </div>
              <button type="button" class="btn text-white mt-5" style="background-color:rgb(213 86 38) !important ">
                <fa icon="check-circle" class="" style="width:20px;height:20px;" />&nbsp;ยืนยัน</button>
            </div>
          </div> -->
        </div>
      </div>


      <div v-if="optionM=='ปริมาณน้ำ'" class="row mx-2 mt-2 ">
        <div class="row">

          <div class="col-12  col-xl-2 border mt-3  ms-2" style="font-weight:bold;color:#424242;">
            <div class="fs-5 mt-2">
              <div class="text-center">บานที่หนึ่ง</div>
              <div class="text-center" style="font-size:12px;">อัตราการไหลปัจจุบัน</div>

              <div class="h1 mt-3 text-center text-success" >{{doorflowS1}} </div>
            <div class="text-center h6 mb-2">ลูกบาศก์เมตร</div>
            </div>
            <div class="text-center" style="font-size:14px ">ความสูงประตูปัจจุบัน | <span style="color:#d39a33;">1.2 เมตร</span></div>

            <hr>
            <div class="row justify-content-center">
              <div class="text-center mt-3">เลือกอัตราการไหล </div>
              <input class="mx-3 mt-3" v-model.number="doorflow1" type="number">
              <div class="text-center" style="font-size:9px;">กรอกอัตราการไหลในหน่วยลูกบาศก์เมตร</div>
              <button type="button" class="btn text-white mt-1" style="background-color:rgb(213 86 38) !important " data-bs-toggle="modal" data-bs-target="#picdoorV1">
                <fa icon="check-circle" class="" style="width:20px;height:20px;" />&nbsp;ยืนยัน</button>
            </div>
          </div>

 <div class="col-12  col-xl-2 border mt-3  ms-2" style="font-weight:bold;color:#424242;">
            <div class="fs-5 mt-2">
              <div class="text-center">บานที่สอง</div>
              <div class="text-center" style="font-size:12px;">อัตราการไหลปัจจุบัน</div>

              <div class="h1 mt-3 text-center text-success" >{{doorflowS2}} </div>
            <div class="text-center h6 mb-2">ลูกบาศก์เมตร</div>
            </div>
            <div class="text-center" style="font-size:14px ">ความสูงประตูปัจจุบัน | <span style="color:#d39a33;">1.2 เมตร</span></div>

            <hr>
            <div class="row justify-content-center">
              <div class="text-center mt-3">เลือกอัตราการไหล </div>
              <input class="mx-3 mt-3" v-model.number="doorflow2" type="number">
              <div class="text-center" style="font-size:9px;">กรอกอัตราการไหลในหน่วยลูกบาศก์เมตร</div>
             <button type="button" class="btn text-white mt-1" style="background-color:rgb(213 86 38) !important " data-bs-toggle="modal" data-bs-target="#picdoorV2">
                <fa icon="check-circle" class="" style="width:20px;height:20px;" />&nbsp;ยืนยัน</button>
            </div>
          </div>

 <div class="col-12  col-xl-2 border mt-3  ms-2" style="font-weight:bold;color:#424242;">
            <div class="fs-5 mt-2">
              <div class="text-center">บานที่สาม</div>
              <div class="text-center" style="font-size:12px;">อัตราการไหลปัจจุบัน</div>

              <div class="h1 mt-3 text-center text-success" >{{doorflowS3}} </div>
            <div class="text-center h6 mb-2">ลูกบาศก์เมตร</div>
            </div>
            <div class="text-center" style="font-size:14px ">ความสูงประตูปัจจุบัน | <span style="color:#d39a33;">1.2 เมตร</span></div>

            <hr>
            <div class="row justify-content-center">
              <div class="text-center mt-3">เลือกอัตราการไหล </div>
              <input class="mx-3 mt-3" v-model.number="doorflow3" type="number">
              <div class="text-center" style="font-size:9px;">กรอกอัตราการไหลในหน่วยลูกบาศก์เมตร</div>
              <button type="button" class="btn text-white mt-1" style="background-color:rgb(213 86 38) !important " data-bs-toggle="modal" data-bs-target="#picdoorV3">
                <fa icon="check-circle" class="" style="width:20px;height:20px;" />&nbsp;ยืนยัน</button>
            </div>
          </div>

 <div class="col-12  col-xl-2 border mt-3  ms-2" style="font-weight:bold;color:#424242;">
            <div class="fs-5 mt-2">
              <div class="text-center">บานที่สี่</div>
              <div class="text-center" style="font-size:12px;">อัตราการไหลปัจจุบัน</div>

              <div class="h1 mt-3 text-center text-success" >{{doorflowS4}} </div>
            <div class="text-center h6 mb-2">ลูกบาศก์เมตร</div>
            </div>
            <div class="text-center" style="font-size:14px ">ความสูงประตูปัจจุบัน | <span style="color:#d39a33;">1.2 เมตร</span></div>

            <hr>
            <div class="row justify-content-center">
              <div class="text-center mt-3">เลือกอัตราการไหล </div>
              <input class="mx-3 mt-3" v-model.number="doorflow4" type="number">
              <div class="text-center" style="font-size:9px;">กรอกอัตราการไหลในหน่วยลูกบาศก์เมตร</div>
              <button type="button" class="btn text-white mt-1" style="background-color:rgb(213 86 38) !important " data-bs-toggle="modal" data-bs-target="#picdoorV4">
                <fa icon="check-circle" class="" style="width:20px;height:20px;" />&nbsp;ยืนยัน</button>
            </div>
          </div>


        </div>
      </div>


<div style="height:60px;"></div>




<!-- Modal -->
<div class="modal fade" id="picdoorV1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body">
        คุณต้องการบันทึกการตั้งค่าประตูน้ำบานที่หนึ่งใช่หรือไม่
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ไม่</button>
         <button type="button" class="btn btn-success" data-bs-dismiss="modal" style="width:60px;" v-on:click="Bflow1(doorflow1)">ใช่</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="picdoorV2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body">
         คุณต้องการบันทึกการตั้งค่าประตูน้ำบานที่สองใช่หรือไม่
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ไม่</button>
         <button type="button" class="btn btn-success" data-bs-dismiss="modal" style="width:60px;" v-on:click="Bflow2(doorflow2)">ใช่</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="picdoorV3" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body">
         คุณต้องการบันทึกการตั้งค่าประตูน้ำบานที่สามใช่หรือไม่
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ไม่</button>
         <button type="button" class="btn btn-success" data-bs-dismiss="modal" style="width:60px;" v-on:click="Bflow3(doorflow3)">ใช่</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="picdoorV4" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body">
         คุณต้องการบันทึกการตั้งค่าประตูน้ำบานที่สี่ใช่หรือไม่
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"  >ไม่</button>
        <button type="button" class="btn btn-success" data-bs-dismiss="modal" style="width:60px;" v-on:click="Bflow4(doorflow4)">ใช่</button>
      </div>
    </div>
  </div>
</div>



    </div>
  </main>


</template>

<script>
  console
  import VueApexCharts from "vue3-apexcharts";
  import Slider from '@vueform/slider';
  export default {
    components: {
      apexchart: VueApexCharts,
      Slider,
    },
    data: function () {
      return {
        G1: 10,
        value: 20,

        optionM: 'ความสูงบานประตู',

        doorflow1: 0,
        doorflow2: 0,
        doorflow3: 0,
        doorflow4: 0,

        doorflowS1: 0,
        doorflowS2: 0,
        doorflowS3: 0,
        doorflowS4: 0,

        series: [{
          name: 'หน้าบาน',
          data: [9, 10, 10, 7, 7, 8, 11],
          //  color:'#1134A6'
          color: '#FD6A6A'
        }, {
          name: 'หลังบาน',
          data: [10, 9, 8, 7, 8, 6, 10],
          color: '#FEB019'

          //  color:'#0080FE'

          //  color:'#1134A6'
        }],
        chartOptions: {
          chart: {
            height: 350,
            type: 'area',
            //  colors:['#FF4560', '#FF4560']
            // style:{
            //     colors:['	#FF4560', '#FF4560']
            //       },

          },

          dataLabels: {
            // style:{
            //       colors:['#FF4560', '#FF4560']
            //         },
            enabled: false,
          },



          // fill:{
          //   colors: ['#b14343', '#b14343']
          // },

          stroke: {
            curve: 'smooth'
          },
          xaxis: {
            type: 'datetime',
            categories: ["2018-09-19T00:00:00.000Z", "2018-09-19T01:30:00.000Z", "2018-09-19T02:30:00.000Z",
              "2018-09-19T03:30:00.000Z", "2018-09-19T04:30:00.000Z", "2018-09-19T05:30:00.000Z",
              "2018-09-19T06:30:00.000Z"
            ]
          },
          tooltip: {
            x: {
              format: 'dd/MM/yy HH:mm'
            },
          },
        },
        series2: [90, 70, 79, 92],
        chartOptions2: {



          chart: {
            height: 300,
            type: 'radialBar',

          },

          plotOptions: {

            radialBar: {

              offsetY: 0,
              startAngle: 0,
              endAngle: 270,

              hollow: {
                margin: 5,
                size: '30%',
                background: 'transparent',
                image: undefined,

              },
              dataLabels: {
                name: {
                  show: false,
                },
                value: {


                }
              },

            }

          },

          colors: ['#1ab7ea', '#0084ff', '#39539E', '#0077B5'],
          labels: ['บานที่ 1 ', 'บานที่ 2 ', 'บานที่ 3 ', 'บานที่ 4 '],
          legend: {
            show: true,
            floating: true,
            fontSize: '14px',
            position: 'left',
            offsetX: 50,
            offsetY: -10,
            labels: {
              useSeriesColors: true,
            },
            markers: {
              size: 0
            },
            formatter: function (seriesName, opts) {
              return seriesName + ":  " + opts.w.globals.series[opts.seriesIndex]
            },
            itemMargin: {
              vertical: 3
            }
          },
          responsive: [{
            breakpoint: 480,
            options: {
              legend: {
                show: false
              }
            }
          }]
        },


        series3: [0],
        series33: this.series3,
        chartOptions3: {
          chart: {
            height: 250,
            type: 'radialBar',
            offsetY: -20
          },
          plotOptions: {
            radialBar: {
              startAngle: -135,
              endAngle: 135,
              dataLabels: {
                name: {
                  fontSize: '16px',
                  color: '#424949',
                  offsetY: 82
                },
                value: {
                  offsetY: -5,
                  fontSize: '20px',
                  color: '#C0392B',
                  formatter: function (val) {
                    return val + "%";
                  }
                }
              }
            }
          },
          fill: {
            type: 'gradient',
            colors: '#C0392B',
            gradient: {

              shade: 'dark',
              shadeIntensity: 0.15,
              inverseColors: false,
              opacityFrom: 1,
              opacityTo: 1,
              stops: [0, 50, 65, 91]

            },

          },
          stroke: {
            dashArray: 4
          },
          labels: ['ความสูงบานประตู(%)'],
        },



        series4: [{
          name: 'หน้าบาน',
          data: [4.5]
        }, {
          name: 'หลังบาน',
          data: [3.5]
        }, ],
        chartOptions4: {
          chart: {
            type: 'bar',
            height: 350
          },
          plotOptions: {
            bar: {
              horizontal: false,
              columnWidth: '70%',
              endingShape: 'rounded'
            },
          },
          dataLabels: {
            enabled: false
          },
          stroke: {
            show: true,
            width: 2,
            colors: ['transparent']
          },
          xaxis: {
            categories: ['หน้าบาน', 'หลังบาน'],
          },
          yaxis: {
            title: {
              text: 'ความสูง (m)'
            }
          },
          fill: {
            opacity: 1,
            colors: ['#1da32e', '#d39a33'],
          },
          tooltip: {
            y: {
              formatter: function (val) {
                return "$ " + val + " thousands"
              }
            }
          }
        },

        series5: [{
          name: 'Net Profit',
          data: [4.5, 3.5, 4.5, 3.0]
        }, ],
        chartOptions5: {
          chart: {
            type: 'bar',
            height: 350
          },
          plotOptions: {
            bar: {
              horizontal: false,
              columnWidth: '55%',
              endingShape: 'rounded'
            },
          },
          dataLabels: {
            enabled: false
          },
          stroke: {
            show: true,
            width: 2,
            colors: ['transparent']
          },
          xaxis: {
            categories: ['บานที่หนึ่ง', 'บานที่สอง', 'บานที่สาม', 'บานที่สี่'],
          },
          yaxis: {
            title: {
              text: 'ความสูง (m)'
            }
          },
          fill: {
            opacity: 1
          },
          tooltip: {
            y: {
              formatter: function (val) {
                return "$ " + val + " thousands"
              }
            }
          }
        },



      };
    },

    methods: {
      updateChart() {
        const max = 90;
        const min = 20;
        const newData = this.series[0].data.map(() => {
          return Math.floor(Math.random() * (max - min + 1)) + min;
        });

        const colors = ["#008FFB", "#00E396", "#FEB019", "#FF4560", "#775DD0"];

        // Make sure to update the whole options config and not just a single property to allow the Vue watch catch the change.
        this.chartOptions = {
          colors: [colors[Math.floor(Math.random() * colors.length)]],
        };

        // In the same way, update the series option
        this.series = [{
          data: newData,
        }, ];
        /** If i try to change the type i will get an error */
        this.type = "line";
      },

        Bflow1:function(val){
          this.doorflowS1=val
          vm.$forceUpdate();
        },
         Bflow2:function(val){
        this.doorflowS2=val
      },
         Bflow3:function(val){
        this.doorflowS3=val
      },
         Bflow4:function(val){
        this.doorflowS4=val
      },
    },




  };
</script>




<style src="@vueform/slider/themes/default.css">

</style>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Prompt:wght@300&display=swap');
  @import url('https://fonts.googleapis.com/css2?family=Itim&display=swap');

  div,
  a {
    font-family: 'Prompt', sans-serif;
    /* font-family: 'Itim', cursive; */
    /* color: rgb(92, 91, 91); */
  }

  .slider-red {
    --slider-connect-bg: #c94b1c;
    --slider-tooltip-bg: #c94b1c;
    --slider-handle-ring-color: #EF444430;

  }

  .sidebar {
    position: fixed
  }

  .dot {
    height: 35px;
    width: 35px;
    background-color: #1da32e;
    border-radius: 50%;
    display: inline-block;
  }
</style>