<template>
 <div class="container-fluid" style="background-color:#F8F9F9;" >
     <header class="navbar navbar-dark sticky-top  flex-md-nowrap p-0 shadow justify-content-center" style="background-color: #212120;" >
        <div class="navbar-nav  d-md-none collapsed mt-2 mb-1">
            <div class="nav-item text-nowrap  ">
                <div class="nav  nav-pills " id="v-pills-tab" role="tablist" aria-orientation="vertical">
                    <a class="nav-link active mx-1" id="v-pills-home-tab" data-bs-toggle="pill"
                        data-bs-target="#v-pills-home" type="button" role="tab" aria-controls="v-pills-home"
                        aria-selected="true">

                       <span style="font-size:13px;">&nbsp;&nbsp;DASHBOARD&nbsp;&nbsp;&nbsp;</span> 
                    </a>
                    <a class="nav-link mx-1  " id="v-pills-manage-tab" data-bs-toggle="pill"
                        data-bs-target="#v-pills-manage" type="button" role="tab" aria-controls="v-pills-manage"
                        aria-selected="false">
                        <span  style="font-size:13px;">&nbsp;&nbsp;USER PROFILE&nbsp;&nbsp;&nbsp;</span> 
                    </a>
                    <a class="nav-link mx-1" id="v-pills-AllView-tab" data-bs-toggle="pill"
                        data-bs-target="#v-pills-AllView" type="button" role="tab" aria-controls="v-pills-AllView"
                        aria-selected="false">
                        <span  style="font-size:13px;">&nbsp;&nbsp;LOGOUT&nbsp;&nbsp;&nbsp;</span> 
                    </a>
                
                </div>
            </div>
        </div>
    </header>
    <div class="row flex-nowrap ">
      <nav id="sidebarMenu" class="col-md-4 col-lg-3 col-xl-2 d-md-block sidebar collapse min-vh-100" style="background-color: #212120; max-width:260px;">
                <div class="container">
                  <div href="/" class="d-flex align-items-center ">
                    <div class="row mt-3 " >
                      <div class="text-white" style="font-weight: bold; font-size:24px;">ประตูน้ำ</div>
                      <div class="text-white" style=" font-size:12px;">Water Gate</div>
                      <!-- <div class="text-white" style=" font-size:12px;">ผู้ใช้งาน : Admin</div> -->
                    </div>          
                </div>
                <hr class="bg-white">
                    <div class="nav flex-column nav-pills mt-5" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                        <div class="nav-link active fs-5 nav-edit" id="v-pills-home-tab" data-bs-toggle="pill"
                            data-bs-target="#v-pills-home" type="button" role="tab" aria-controls="v-pills-home"
                            aria-selected="true">
                          <div class="text-white" style="font-size:13px; font-weight: bold;"><fa icon="chart-bar"  style="width:25px;height:25px;" /> &nbsp;DASHBOARD</div>
                        </div>
                        <div class="nav-link fs-5 nav-edit" id="v-pills-manage-tab" data-bs-toggle="pill"
                            data-bs-target="#v-pills-manage" type="button" role="tab" aria-controls="v-pills-manage"
                            aria-selected="false">
                            <span class="text-white"  style="font-size:13px; font-weight: bold;"><fa icon="address-card"  style="width:25px;height:25px" /> &nbsp;USER PROFILE</span> 
                        </div>
                        <!-- <div class="nav-link fs-5 nav-edit" id="v-pills-Control-tab" data-bs-toggle="pill"
                            data-bs-target="#v-pills-Control" type="button" role="tab" aria-controls="v-pills-Control"
                            aria-selected="false">
                           <span class="text-white" style="font-size:13px; font-weight: bold;"><fa icon="book"  style="width:25px;height:25px" /> &nbsp;CONTROL</span> 
                        </div> -->
                        <div class="nav-link fs-5 nav-edit" id="v-pills-Control-tab" data-bs-toggle="pill"
                            data-bs-target="#v-pills-Control" type="button" role="tab" aria-controls="v-pills-Control"
                            aria-selected="false">
                           <span class="text-white" style="font-size:13px; font-weight: bold;"><fa icon="sign-out-alt"   style="width:25px;height:25px" /> &nbsp;LOGOUT</span> 
                        </div>
                    </div>
                </div>
            </nav>
            
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4" style="background-color:#F8F9F9;height:100vh;">
    <div class="row">
        <div class="col">
          <div class="mt-4 ms-4 text-center fs-4" style="font-weight:bold;color:grey;" >DASHBOARD</div>   
        </div>
        <!-- <div class="col text-end">
           <button type="button" class="btn mt-3  text-white" style="background-color:rgb(213 86 38) !important"><fa icon="folder-plus" class="pt-2" style="width:25px;height:25px;" />&nbsp;Add Station</button>
        </div> -->
    </div>
    
 <hr>
<div class="col-12">
    <div class="row  ms-5">
     
   <div class="col-xl-3 col-lg-4 col-md-6  col-sm-6 col-12 "   >
        <div class="card  mb-3 shadow p-3 mb-5 bg-body rounded-3 " style="max-width: 22rem;height:333px; ">
         <h6 class="card-title " style="font-weight:bold;color:#ff4b05;">ปตร.กลางคลองระพีพัฒน์แยกตก</h6>
         <router-link to="/dashboard" style="text-decoration: none; color: inherit;">
            <div class="card-body  ">
                
                  <div class="card-text"  style="font-weight:bold;color:grey">
                    <a style="color:#3E3E3E;"> สถานะ:</a> <a style="color:#1da32e;">Online</a>
                    <hr>
                   <div style="color:#3E3E3E">สถานะประตูน้ำ</div>
                  <li style="color:#24A157;"><a style="font-size:14px; color:grey;">บานที่หนึ่ง : <a style="font-size:14px;color:#1da32e;;">5&nbsp;.&nbsp;55 เมตร</a>  </a></li> 
                  <li style="color:#24A157;"><a style="font-size:14px; color:grey;">บานที่สอง : <a style="font-size:14px;color:#1da32e;;">6&nbsp;.&nbsp;54 เมตร</a></a></li> 
                  <li style="color:#24A157;"><a style="font-size:14px; color:grey;">บานที่สาม : <a style="font-size:14px;color:#1da32e;;">4&nbsp;.&nbsp;55 เมตร</a></a></li> 
                  
                   <div style="color:#3E3E3E">สถานะระดับน้ำ</div>
                   <li style="color:#24A157;"><a style="font-size:14px; color:grey;">หน้าบาน : <a style="font-size:14px;color:#1da32e;;">5&nbsp;.&nbsp;55 เมตร</a></a></li> 
                   <li style="color:#24A157;"><a style="font-size:14px; color:grey;">หลังบาน : <a style="font-size:14px;color:#1da32e;;">4&nbsp;.&nbsp;55 เมตร</a></a></li> 
              
                </div>
              <a href="https://stackoverflow.com/questions/54404865/make-bootstrap-card-entirely-clickable" class=" stretched-link"></a>
            </div>
            </router-link>
        </div>
    </div>

      <div class="col-xl-3 col-lg-4 col-md-6  col-sm-6 col-12 "  >
      <div class="card  mb-3 shadow p-3 mb-5 bg-body rounded-3" style="max-width: 22rem;height:333px; ">
      <h6 class="card-title " style="font-weight:bold;color:#ff4b05;">ปตร.เปรมเหนือบางปะอิน</h6>
            <router-link to="/dashboard" style="text-decoration: none; color: inherit;">
            <div class="card-body  ">
               
                  <div class="card-text"  style="font-weight:bold;color:grey">
               
                    <a style="color:#3E3E3E;"> สถานะ:</a> <a style="color:#1da32e;">Online</a>
                    
                    <hr>
                  <div style="color:#3E3E3E">สถานะประตูน้ำ</div>
                  <li style="color:#24A157;"><a style="font-size:14px; color:grey;">บานที่หนึ่ง : <a style="font-size:14px;color:#1da32e;;">5 เมตร</a>  </a></li> 
                  <li style="color:#24A157;"><a style="font-size:14px; color:grey;">บานที่สอง : <a style="font-size:14px;color:#1da32e;;">6 เมตร</a></a></li> 
                  <li style="color:#24A157;"><a style="font-size:14px; color:grey;">บานที่สาม : <a style="font-size:14px;color:#1da32e;;">4 เมตร</a></a></li> 
                  <li style="color:#24A157;"><a style="font-size:14px; color:grey;">บานที่สี่&nbsp;&nbsp;&nbsp;: <a style="font-size:14px;color:#1da32e;;">3 เมตร</a></a></li> 
                   <div style="color:#3E3E3E">สถานะระดับน้ำ</div>
                   <li style="color:#24A157;"><a style="font-size:14px; color:grey;">หน้าบาน : <a style="font-size:14px;color:#1da32e;;">5&nbsp;.&nbsp;55 เมตร</a></a></li> 
                   <li style="color:#24A157;"><a style="font-size:14px; color:grey;">หลังบาน : <a style="font-size:14px;color:#1da32e;;">4&nbsp;.&nbsp;55 เมตร</a></a></li> 
              
                </div>
              
            </div>
             </router-link>
        </div>
    </div>
       <div class="col-xl-3 col-lg-4 col-md-6  col-sm-6 col-12 "  >
        <div class="card  mb-3 shadow p-3 mb-5 bg-body rounded-3" style="max-width: 22rem;height:333px; ">
 <h6 class="card-title " style="font-weight:bold;color:#ff4b05;">ปตร.เปรมเหนือบางปะอิน</h6>
             <router-link to="/dashboard" style="text-decoration: none; color: inherit;">
            <div class="card-body  ">   
                  <div class="card-text"  style="font-weight:bold;color:grey">    
                  <a style="color:#3E3E3E;"> สถานะ:</a> <a style="color:#1da32e;">Online</a>
                  <hr>
                  <div style="color:#3E3E3E">สถานะประตูน้ำ</div>
                  <li style="color:#24A157;"><a style="font-size:14px; color:grey;">บานที่หนึ่ง : <a style="font-size:14px;color:#1da32e;;">5 เมตร</a>  </a></li> 
                  <li style="color:#24A157;"><a style="font-size:14px; color:grey;">บานที่สอง : <a style="font-size:14px;color:#1da32e;;">6 เมตร</a></a></li> 
                  <li style="color:#24A157;"><a style="font-size:14px; color:grey;">บานที่สาม : <a style="font-size:14px;color:#1da32e;;">4 เมตร</a></a></li> 
                  <li style="color:#24A157;"><a style="font-size:14px; color:grey;">บานที่สี่&nbsp;&nbsp;&nbsp;: <a style="font-size:14px;color:#1da32e;;">3 เมตร</a></a></li> 
                   <div style="color:#3E3E3E">สถานะระดับน้ำ</div>
                   <li style="color:#24A157;"><a style="font-size:14px; color:grey;">หน้าบาน : <a style="font-size:14px;color:#1da32e;;">5&nbsp;.&nbsp;55 เมตร</a></a></li> 
                   <li style="color:#24A157;"><a style="font-size:14px; color:grey;">หลังบาน : <a style="font-size:14px;color:#1da32e;;">4&nbsp;.&nbsp;55 เมตร</a></a></li> 
                </div>
            </div>
             </router-link>
        </div>
    </div>
           <div class="col-xl-3 col-lg-4 col-md-6  col-sm-6 col-12 "  >
        <div class="card  mb-3 shadow p-3 mb-5 bg-body rounded-3" style="max-width: 22rem;height:333px; ">
 <h6 class="card-title " style="font-weight:bold;color:#ff4b05;">ปตร.เปรมเหนือบางปะอิน</h6>
            <router-link to="/dashboard" style="text-decoration: none; color: inherit;">
            <div class="card-body  ">            
                  <div class="card-text"  style="font-weight:bold;color:grey">      
                   <a style="color:#3E3E3E;"> สถานะ:</a> <a style="color:#1da32e;">Online</a> 
                   <hr>
                  <div style="color:#3E3E3E">สถานะประตูน้ำ</div>
                  <li style="color:#24A157;"><a style="font-size:14px; color:grey;">บานที่หนึ่ง : <a style="font-size:14px;color:#1da32e;;">5 เมตร</a>  </a></li> 
                  <li style="color:#24A157;"><a style="font-size:14px; color:grey;">บานที่สอง : <a style="font-size:14px;color:#1da32e;;">6 เมตร</a></a></li> 
                  <li style="color:#24A157;"><a style="font-size:14px; color:grey;">บานที่สาม : <a style="font-size:14px;color:#1da32e;;">4 เมตร</a></a></li> 
                  <li style="color:#24A157;"><a style="font-size:14px; color:grey;">บานที่สี่&nbsp;&nbsp;&nbsp;: <a style="font-size:14px;color:#1da32e;;">3 เมตร</a></a></li> 
                  <div style="color:#3E3E3E">สถานะระดับน้ำ</div>
                  <li style="color:#24A157;"><a style="font-size:14px; color:grey;">หน้าบาน : <a style="font-size:14px;color:#1da32e;;">5&nbsp;.&nbsp;55 เมตร</a></a></li> 
                  <li style="color:#24A157;"><a style="font-size:14px; color:grey;">หลังบาน : <a style="font-size:14px;color:#1da32e;;">4&nbsp;.&nbsp;55 เมตร</a></a></li> 
                </div> 
            </div>
             </router-link>
        </div>
    </div>

 </div>
</div>

<!-- <div class="tab-content" id="v-pills-tabContent">
<div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">  

</div>
<div class="tab-pane fade" id="v-pills-manage" role="tabpanel" aria-labelledby="v-pills-manage-tab"> 

</div>
</div> -->
</main>
</div>
</div>
</template>

<script>
import VueApexCharts from "vue3-apexcharts";
export default {
  components: {
    apexchart: VueApexCharts,
  },
  data: function () {
    return {
 series: [{
            name: 'อุณหถูมิน้ำ',
            data: [31, 40, 28, 51, 42, 109, 100]
          }, {
            name: 'คุณภาพน้ำ',
            data: [11, 32, 45, 32, 34, 52, 41]
          }],
          chartOptions: {
            chart: {
              height: 350,
              type: 'area'
            },
            dataLabels: {
              enabled: false
            },
            stroke: {
              curve: 'smooth'
            },
            xaxis: {
              type: 'datetime',
              categories: ["2018-09-19T00:00:00.000Z", "2018-09-19T01:30:00.000Z", "2018-09-19T02:30:00.000Z", "2018-09-19T03:30:00.000Z", "2018-09-19T04:30:00.000Z", "2018-09-19T05:30:00.000Z", "2018-09-19T06:30:00.000Z"]
            },
            tooltip: {
              x: {
                format: 'dd/MM/yy HH:mm'
              },
            },
          },
    };
  },

  methods: {
    updateChart() {
      const max = 90;
      const min = 20;
      const newData = this.series[0].data.map(() => {
        return Math.floor(Math.random() * (max - min + 1)) + min;
      });

      const colors = ["#008FFB", "#00E396", "#FEB019", "#FF4560", "#775DD0"];

      // Make sure to update the whole options config and not just a single property to allow the Vue watch catch the change.
      this.chartOptions = {
        colors: [colors[Math.floor(Math.random() * colors.length)]],
      };

      // In the same way, update the series option
      this.series = [
        {
          data: newData,
        },
      ];
      /** If i try to change the type i will get an error */
      this.type = "line";
    },
  },
};
</script>

<style>
@import url('https://fonts.googleapis.com/css2?family=Prompt:wght@300&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Itim&display=swap');
div
{
    font-family: 'Prompt', sans-serif;
    /* font-family: 'Itim', cursive; */
    /* color: rgb(92, 91, 91); */
}
.nav-pills .nav-link.active {
    /* background-color: hsl(130, 85%, 61%) !important; */
    background-color:#ed521896!important;
    color: #ffffff !important;
}
.dot {
  height: 25px;
  width: 25px;
  background-color: rgb(22, 117, 65);
  border-radius: 50%;
  display: inline-block;
}
.sidebar {
position: fixed 
}
</style>