<template>
  <router-view />
  <!-- <dashboard/> -->
  <!-- <indashboard/> -->
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue'
// import dashboard from './components/dashboard.vue'
// import indashboard from './components/indashboard.vue'
// import center from './components/centerfile.js'
export default {
  name: 'App',
  components: {
    // dashboard,
    // indashboard,
  }
}
</script>
   
<style>
#app {
  /* font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px; */
}
</style>
